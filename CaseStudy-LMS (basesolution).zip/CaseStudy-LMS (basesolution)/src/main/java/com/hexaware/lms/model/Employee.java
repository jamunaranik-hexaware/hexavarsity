package com.hexaware.lms.model;

import com.hexaware.lms.persistence.DbConnection;
import com.hexaware.lms.persistence.EmployeeDAO;
import java.util.Objects;
import java.util.List;
import java.util.Date;
import java.text.ParseException;

public class Employee {

 
  private int empId;
  private String empName;
  private int empMgrId;
  private int empLevBalance;

  @Override
  public final boolean equals(final Object obj) {
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    Employee emp = (Employee) obj;
    if (Objects.equals(empId, emp.empId) && Objects.equals(empName, emp.empName)
        && Objects.equals(empMgrId, emp.empMgrId)
        && Objects.equals(empLevBalance, emp.empLevBalance)) {
      return true;
    }
    return false;
  }
  @Override
  public final int hashCode() {
    return Objects.hash(empId, empName, empMgrId, empLevBalance);
  }

  public Employee(final int argEmpId, final String argEmpName, final int argEmpMgrId, final int argEmpLevBalance) {
    this.empId = argEmpId;
    this.empName = argEmpName;
    this.empMgrId = argEmpMgrId;
    this.empLevBalance = argEmpLevBalance;
  }
  
  public Employee(final int argEmpId) {
    this.empId = argEmpId;
  }
 
  public Employee() {
  }
 
  public final int getEmpId() {
    return empId;
  }
   
  public final String getEmpName() {
    return empName;
  }
   
  public final int getMgrId() {
    return empMgrId;
  }
   
  public final int getEmpLevBalance() {
    return empLevBalance;
  }
  
  public final void setEmpId(final int argEmpId) {
    this.empId = argEmpId;
  }
  
  public final void setEmpName(final String argEmpName) {
    this.empName = argEmpName;
  }
 
  public final void setMgrId(final int argEmpMgrId) {
    this.empMgrId = argEmpMgrId;
  }
  
  
  public final void setEmpLevBalance(final int argEmpLevBalance) {
    this.empLevBalance = argEmpLevBalance;
  }
  
  public static EmployeeDAO dao() {
    DbConnection db = new DbConnection();
    return db.getConnect().onDemand(EmployeeDAO.class);
  }
 /*
  public static Employee[] listAll() {
   
  }
  
 
  public static String applyLev() {
    
    if (//condition) {
      "Insufficient Balance !!";
    } else {
       "Your Leave Approval sent to manager";
    }
   
  }*/
}
