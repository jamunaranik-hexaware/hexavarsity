package com.hexaware.lms.persistence;


import com.hexaware.lms.model.LeaveDetails;


import java.util.List;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;

import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;

/**
 * The DAO class for LeaveDetails.
 */
public interface LeaveDetailsDAO  {
  
 
  @SqlQuery("//insert your code here")
  @Mapper(LeaveDetailsMapper.class)
  List<LeaveDetails> leaveHistory(@Bind("empId") int empId);

  
  @SqlUpdate("//insert your code here")
  int updateLeave(@Bind("balance") int balance, @Bind("empId") int empId);
  
  

  @SqlUpdate("//insert your code here")
  int applyForLeave(@Bind("levStartDate") String levStartDate, @Bind("levEndDate") String levEndDate,
      @Bind("levNoOfDays") int levNoOfDays,  @Bind("levReason") String levReason, @Bind("levEmpId") int levEmpId);
 
 
  void close();
}
