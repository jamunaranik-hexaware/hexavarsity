
package com.hexaware.lms.persistence;

import com.hexaware.lms.model.Employee;


import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;

import java.util.List;


public interface EmployeeDAO  {
 
  @SqlQuery("//insert your code")
  @Mapper(EmployeeMapper.class)
  List<Employee> list();
  
  @SqlQuery("//insert your code")
  @Mapper(EmployeeMapper.class)
  Employee find(@Bind("empID") int empID);
 

  @SqlUpdate("//insert your code")
  int updateBalAvailable(@Bind("day") int day, @Bind("empID") int empId);

  
  void close();
}
