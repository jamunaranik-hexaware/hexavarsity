package com.hexaware.lms.model;

import java.util.Objects;
import java.util.Date;
import com.hexaware.lms.persistence.DbConnection;
import com.hexaware.lms.persistence.LeaveDetailsDAO;
import java.util.List;


public class LeaveDetails {

  private int levId;
  private Date levDateApplied;
  private Date levStartDate;
  private Date levEndDate;
  private int levNoOfDays;
  private String levReason;
  private int levEmpId;

  @Override
  public final boolean equals(final Object obj) {
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    LeaveDetails lev = (LeaveDetails) obj;
    if (Objects.equals(levId, lev.levId) && Objects.equals(levDateApplied, lev.levDateApplied)
        && Objects.equals(levStartDate, lev.levStartDate) && Objects.equals(levEndDate, lev.levEndDate)
        && Objects.equals(levNoOfDays, lev.levNoOfDays) 
         && Objects.equals(levReason, lev.levReason)
        && Objects.equals(levEmpId, lev.levEmpId)) {
      return true;
    }
    return false;
  }
  @Override
  public final int hashCode() {
    return Objects.hash(levId, levDateApplied, levStartDate, levEndDate, levNoOfDays, 
        levReason, levEmpId);
  }
  
  public LeaveDetails(final int argLevId, final Date argLevDateApplied, final Date argLevStartDate,
      final Date argLevEndDate, final int argLevNoOfDays, 
      final String argLevReason,  final int argLevEmpId) {
    this.levId = argLevId;
    this.levDateApplied = argLevDateApplied;
    this.levStartDate = argLevStartDate;
    this.levEndDate = argLevEndDate;
    this.levNoOfDays = argLevNoOfDays;
    this.levReason = argLevReason;
    this.levEmpId = argLevEmpId;
  }
   
  public LeaveDetails(final int argLevEmpId) {
    this.levEmpId = argLevEmpId;
  }

  
  public LeaveDetails() {

  }
  
  public final int getLevId() {
    return levId;
  }
  
  public final Date getLevDateApplied() {
    return levDateApplied;
  }
  
  public final Date getLevStartDate() {
    return levStartDate;
  }
  
  public final Date getLevEndDate() {
    return levEndDate;
  }
 
  public final int getLevNoOfDays() {
    return levNoOfDays;
  }
  
  /**
   *  Gets the Leave Reason.
   * @return this Reason.
   */
  public final String getLevReason() {
    return levReason;
  }
  
   
  public final int getLevEmpId() {
    return levEmpId;
  }

  public final void setLevId(final int argLevId) {
    this.levId = argLevId;
  }
  
  public final void setLevDateApplied(final Date argLevDateApplied) {
    this.levDateApplied = argLevDateApplied;
  }
  
  public final void setLevStartDate(final Date argLevStartDate) {
    this.levStartDate = argLevStartDate;
  }
 
  public final void setLevEndDate(final Date argLevEndDate) {
    this.levEndDate = argLevEndDate;
  }
  
  public final void setLevNoOfDays(final int argLevNoOfDays) {
    this.levNoOfDays = argLevNoOfDays;
  }
  
  public final void setLevReason(final String argLevReason) {
    this.levReason = argLevReason;
  }
  
  
  public final void setLevEmpId(final int argLevEmpId) {
    this.levEmpId = argLevEmpId;
  }
   
  @Override
  public final String toString() {
    return   levId + " \t " + levDateApplied + " \t " + levStartDate
      + " \t " + levEndDate + " \t " + levNoOfDays + " \t " + levReason
      + "\t " + "\t" + levEmpId;
  }
  
    public static LeaveDetailsDAO dao() {
    DbConnection db = new DbConnection();
    return db.getConnect().onDemand(LeaveDetailsDAO.class);
  }
  /* public static LeaveDetails[] listById() {
   
  }*/
}
