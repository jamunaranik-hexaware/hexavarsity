package com.hexaware.lms.util;
import java.util.Scanner;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.InputMismatchException;
import com.hexaware.lms.model.Employee;
import com.hexaware.lms.model.LeaveDetails;
import java.text.ParseException;

/**
 * Class CliMain provides the command line interface to the leavemanagement
 * application.
 */
public class CliMain {
  private Scanner option = new Scanner(System.in, "UTF-8");

  private void mainMenu() {
   
      System.out.println("\nLeave Management System");
      System.out.println("-----------------------");
      System.out.println("1. List All Employees Info");
      System.out.println("2. Apply for leave");
      System.out.println("3. Leave History");
      System.out.println("4. Exit");
      System.out.println("\nEnter your choice:");
      int menuOption = option.nextInt();
      
      mainMenuDetails(menuOption);
   
  }
  private void mainMenuDetails(final int selectedOption) {
    switch (selectedOption) {
      case 1:
        listEmployeesDetails();
        break;
      case 2:
        applyForLev();
        break;
      case 3:
        leaveHistory();
        break;
      case 4:
        // halt since normal exit throws a stacktrace due to jdbc threads not responding
        Runtime.getRuntime().halt(0);
      default:
        System.out.println("Choose any of the Following Option:\n");
    }
    mainMenu();
  }
  
  private void listEmployeesDetails() {
   //insert your code here
  }
  

    
  private void leaveHistory()  {
     //insert your code here
      
    
  }
  private void applyForLev() {
     //insert your code here
  }
   /**
   * The main entry point.
   * @param ar the list of arguments
   */
  public static void main(final String[] ar) {
    final CliMain mainObj = new CliMain();
    mainObj.mainMenu();
  }
}
