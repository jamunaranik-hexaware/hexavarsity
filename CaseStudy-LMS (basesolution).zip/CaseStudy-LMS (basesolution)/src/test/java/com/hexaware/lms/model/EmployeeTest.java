package com.hexaware.lms.model;

import com.hexaware.lms.persistence.EmployeeDAO;
import com.hexaware.lms.persistence.LeaveDetailsDAO;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import mockit.Expectations;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Mock;
import mockit.integration.junit4.JMockit;
import java.text.SimpleDateFormat;

import java.text.ParseException;

import java.util.ArrayList;

/**
 * Test class for Employee.
 */
@RunWith(JMockit.class)
public class EmployeeTest {

  /**
   * setup method.
   */
  @Before
  public void initInput() {

  }

  
 
  /**
   * Tests that a list with some employees is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testListAll(@Mocked final EmployeeDAO dao) {
    new Expectations() {
      {
        ArrayList<Employee> es = new ArrayList<Employee>();
        es.add(new Employee(1000,"Naresh",0,5));
        es.add(new Employee(1001,"Ram",1000,10));
        dao.list(); result = es;
      }
    };
    new MockUp<Employee>() {
      @Mock
      EmployeeDAO dao() {
        return dao;
      }
    };
    Employee[] es = Employee.listAll();
    assertEquals(new Employee(1000,"Naresh",0,5), es[0]);
    assertEquals(new Employee(1001,"Ram",1000,10), es[1]);
   
  }

  
    /**
   * Tests that a list with some employees is handled correctly.
   * @param dao mocking the leave dao class.
   * @param empdao mocking the employee dao class.
   * @throws ParseException catches the date parsing Exception.
   */
  @Test
  public final void testapplyLev(@Mocked final LeaveDetailsDAO dao, @Mocked final EmployeeDAO empdao)
  throws ParseException {
   
    Employee e1 = new Employee();
    new Expectations() {
      {
        dao.applyForLeave("2018-02-13", "2018-02-14", 2, "Headache",
            3000);
        result = 1;
        dao.updateLeave(6, 3000);
        result = 1;
      }
    };
    new Expectations() {
      {
        Employee e101 = new Employee(3000, "AMAR", 2000, 8);
        empdao.find(3000); result = e101;
      }
    };

    new MockUp<LeaveDetails>() {
      @Mock
      LeaveDetailsDAO dao() {
        return dao;
      }
    };

    new MockUp<Employee>() {
      @Mock
      EmployeeDAO dao() {
        return empdao;
      }
    };
    String s = e1.applyLev("2018-02-13", "2018-02-14", 2, "Headache", 3000);
    assertEquals("Your Leave Approval sent to manager", s);
    assertNotEquals("Insufficient balance", s);
    
  }
  
}
