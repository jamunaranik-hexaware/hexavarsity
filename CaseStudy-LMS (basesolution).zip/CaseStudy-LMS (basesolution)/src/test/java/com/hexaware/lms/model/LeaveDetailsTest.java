import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import com.hexaware.lms.persistence.LeaveDetailsDAO;
import com.hexaware.lms.persistence.EmployeeDAO;
import com.hexaware.lms.model.Employee;
import com.hexaware.lms.model.LeaveDetails;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.junit.Test;
import mockit.Expectations;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Mock;
import mockit.integration.junit4.JMockit;

//import java.util.Date;

/**
 * Test class for LeaveDetails.
 */
@RunWith(JMockit.class)
public class LeaveDetailsTest {
  /**
   * setup method.
   */
  @Before
  public void initInput() {

  }

  /**
  * tests the leavedetails for a given id.
  * @param dao is the mocked object.
  */
  @Test
  public final void testListById(@Mocked final LeaveDetailsDAO dao) throws ParseException {
    final SimpleDateFormat sf = new SimpleDateFormat("yyyy/MM/dd");
    new Expectations() {
      {
        ArrayList<LeaveDetails> ld = new ArrayList<LeaveDetails>();
        ld.add(new LeaveDetails(123, sf.parse("2018/02/02"), sf.parse("2018/02/03"),
        sf.parse("2018/02/04"), 2,"medical",2000));
        ld.add(new LeaveDetails(124, sf.parse("2018/02/03"), sf.parse("2018/02/06"), sf.parse("2018/02/09"),
        4,"sick", 2000));
        
        dao.leaveHistory(2000);
        result = ld;
      }
    };
    new MockUp<LeaveDetails>() {
      @Mock
      LeaveDetailsDAO dao() {
        return dao;
      }
    };
    LeaveDetails[] led = LeaveDetails.listById(2000);
    assertEquals(new LeaveDetails(123, sf.parse("2018/02/02"), sf.parse("2018/02/03"),
        sf.parse("2018/02/04"), 2,"medical",2000), led[0]);
       }

 
 
}
