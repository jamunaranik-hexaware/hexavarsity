package com.hexaware.lms.model;

import com.hexaware.lms.persistence.DbConnection;
import com.hexaware.lms.persistence.EmployeeDAO;
import java.util.Objects;
import java.util.List;
import java.util.Date;
import java.text.ParseException;

/**
 * Employee class to store employee personal details.
 * @author hexware
 */
public class Employee {

  /**
   * empId to store employee id.
   */
  private int empId;
  /**
   * empName to store employee Name.
   */
  private String empName;
  /**
   * empMgrId to store employee's Manager Id.
   */
  private int empMgrId;
  /**
   * empLevBalance to store employee Leave Balance.
   */
  private int empLevBalance;

  @Override
  public final boolean equals(final Object obj) {
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    Employee emp = (Employee) obj;
    if (Objects.equals(empId, emp.empId) && Objects.equals(empName, emp.empName)
        && Objects.equals(empMgrId, emp.empMgrId)
        && Objects.equals(empLevBalance, emp.empLevBalance)) {
      return true;
    }
    return false;
  }
  @Override
  public final int hashCode() {
    return Objects.hash(empId, empName, empMgrId, empLevBalance);
  }

  /**
   * @param argEmpId to initialize employee id.
   * @param argEmpName to initialize employee Name.
   * @param argEmpPhone to initialize employee Phone Number.
   * @param argEmpEmail to initialize employee Email.
   * @param argEmpDoj to initialize employee Date of Joining.
   * @param argEmpMgrId to initialize employee's Manager Id.
   * @param argEmpDeptName to initialize employee Department name.
   * @param argEmpLevBalance to initialize employee Leave Balance.
   */
  public Employee(final int argEmpId, final String argEmpName, final int argEmpMgrId, final int argEmpLevBalance) {
    this.empId = argEmpId;
    this.empName = argEmpName;
    this.empMgrId = argEmpMgrId;
    this.empLevBalance = argEmpLevBalance;
  }
  /**
   * @param argEmpId to initialize employee id.
   */
  public Employee(final int argEmpId) {
    this.empId = argEmpId;
  }
 /**
  *Default Constructor.
  */
  public Employee() {
  }
  /**
   * Gets the EmployeeId.
   * @return this Employee's ID.
   */
  public final int getEmpId() {
    return empId;
  }
   /**
   * Gets the EmployeeName.
   * @return this Employee's Name.
   */
  public final String getEmpName() {
    return empName;
  }
   
   
   /**
   * Gets the Employee Manager Id.
   * @return this Employee's MgrId
   */
  public final int getMgrId() {
    return empMgrId;
  }
   
   /**
   * Gets the Employee Leave Balance.
   * @return this Employee's LevBalance.
   */
  public final int getEmpLevBalance() {
    return empLevBalance;
  }
  /**
   *
   * @param argEmpId to set employee id.
   */
  public final void setEmpId(final int argEmpId) {
    this.empId = argEmpId;
  }
  /**
   *
   * @param argEmpName to set employee name.
   */
  public final void setEmpName(final String argEmpName) {
    this.empName = argEmpName;
  }
  
  /**
   *
   * @param argEmpMgrId to set employee manager id.
   */
  public final void setMgrId(final int argEmpMgrId) {
    this.empMgrId = argEmpMgrId;
  }
  
  /**
   *
   * @param argEmpLevBalance to set employee leave balance.
   */
  public final void setEmpLevBalance(final int argEmpLevBalance) {
    this.empLevBalance = argEmpLevBalance;
  }
  /**
   * The dao for employee.
   * @return all the employee details
   */
  public static EmployeeDAO dao() {
    DbConnection db = new DbConnection();
    return db.getConnect().onDemand(EmployeeDAO.class);
  }
  /**
   * list all employee details.
   * @return all employees' details
   */
  public static Employee[] listAll() {

    List<Employee> es = dao().list();
    return es.toArray(new Employee[es.size()]);
  }
  /**
   * list employee details by id.
   * @param empID id to get employee details.
   * @return Employee
   */
  public static Employee listById(final int empID) {
    return dao().find(empID);
  }
   
  /**
   * To check whether the applied days for leave is greater than available balance.
   * @param levNoOfDays to initialize the no. of days of leave.
   * @param levEmpId to initialize the employee id.
   * @return string b.
   */
  public static String applyLev(final String levStartDate, final String levEndDate, final int levNoOfDays,
                        final String levReason, final int levEmpId) throws ParseException {
    Employee emp = Employee.listById(levEmpId);
    int levbalance = emp.getEmpLevBalance();
    String b = null;
    
    
    if (levNoOfDays > levbalance) {
      b = "Insufficient Balance !!";
    } else {
     
       int levBalance = levbalance - levNoOfDays;
        LeaveDetails.dao().applyForLeave(levStartDate, levEndDate, levNoOfDays,
             levReason, levEmpId);
        LeaveDetails.dao().updateLeave(levBalance, levEmpId);
       b = "Your Leave Approval sent to manager";
    }
    return b;
  }
}
