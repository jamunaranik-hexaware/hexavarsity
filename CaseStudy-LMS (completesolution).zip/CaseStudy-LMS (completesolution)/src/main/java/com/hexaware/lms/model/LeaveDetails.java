package com.hexaware.lms.model;

import java.util.Objects;
import java.util.Date;
import com.hexaware.lms.persistence.DbConnection;
import com.hexaware.lms.persistence.LeaveDetailsDAO;
import java.util.List;



/**
 * leavedetail class to store leave details.
 * @author hexware
 */
public class LeaveDetails {

  /**
   * levId to store employee Leave id.
   */
  private int levId;

  /**
   * levDateApplied to store when the leave is applied.
   */
  private Date levDateApplied;
  /**
   * levStartDate to store start date of leave.
   */
  private Date levStartDate;
  /**
   * levEndDate to store end date of leave.
   */
  private Date levEndDate;
  /**
   * levNoOfDays to store count of leave days.
   */
  private int levNoOfDays;
  /**
   *levReason to store reason for the leave.
   */
  private String levReason;
  
  /**
   *levEmpId to store the employee id of the employee.
   */
  private int levEmpId;
  @Override
  public final boolean equals(final Object obj) {
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    LeaveDetails lev = (LeaveDetails) obj;
    if (Objects.equals(levId, lev.levId) && Objects.equals(levDateApplied, lev.levDateApplied)
        && Objects.equals(levStartDate, lev.levStartDate) && Objects.equals(levEndDate, lev.levEndDate)
        && Objects.equals(levNoOfDays, lev.levNoOfDays) 
         && Objects.equals(levReason, lev.levReason)
        && Objects.equals(levEmpId, lev.levEmpId)) {
      return true;
    }
    return false;
  }
  @Override
  public final int hashCode() {
    return Objects.hash(levId, levDateApplied, levStartDate, levEndDate, levNoOfDays, 
        levReason, levEmpId);
  }
  /**
   * @param argLevId to initialize leave id.
   * @param argLevDateApplied to initialize leave date applied.
   * @param argLevStartDate to initialize leave start date.
   * @param argLevEndDate to initialize leave end date.
   * @param argLevNoOfDays to initialize leave no_of_days.
   * @param argLevType to initialize leave type.
   * @param argLevStatus to initialize leave status.
   * @param argLevReason to initialize leave reason.
   * @param argLevMgrComments to initialize leave manager comments.
   * @param argLevEmpId to initialize the employee Id.
   */
  public LeaveDetails(final int argLevId, final Date argLevDateApplied, final Date argLevStartDate,
      final Date argLevEndDate, final int argLevNoOfDays, 
      final String argLevReason,  final int argLevEmpId) {
    this.levId = argLevId;
    this.levDateApplied = argLevDateApplied;
    this.levStartDate = argLevStartDate;
    this.levEndDate = argLevEndDate;
    this.levNoOfDays = argLevNoOfDays;
    this.levReason = argLevReason;
    this.levEmpId = argLevEmpId;
  }
   /**
   * @param argLevEmpId to initialize the employee Id.
   */
  public LeaveDetails(final int argLevEmpId) {
    this.levEmpId = argLevEmpId;
  }

  /**
   * Default Constructor.
   */
  public LeaveDetails() {

  }
  /**
   * Gets the Leave Id.
   * @return this Leave Id
   */
  public final int getLevId() {
    return levId;
  }
  /**
   * Gets the Leave date applied.
   * @return this date applied.
   */
  public final Date getLevDateApplied() {
    return levDateApplied;
  }
  /**
   * Gets the Leave start date.
   * @return this start date.
   */
  public final Date getLevStartDate() {
    return levStartDate;
  }
  /**
   *  Gets the Leave end date.
   * @return this end date.
   */
  public final Date getLevEndDate() {
    return levEndDate;
  }
  /**
   *  Gets the No of leave days.
   * @return this No of days.
   */
  public final int getLevNoOfDays() {
    return levNoOfDays;
  }
  
  /**
   *  Gets the Leave Reason.
   * @return this Reason.
   */
  public final String getLevReason() {
    return levReason;
  }
  
   /**
   *Gets the Employee Id.
   * @return this employee Id.
   */
  public final int getLevEmpId() {
    return levEmpId;
  }

  /**
   *
   * @param argLevId to set LeaveId.
   */
  public final void setLevId(final int argLevId) {
    this.levId = argLevId;
  }
  /**
   *
   * @param argLevDateApplied to set levloyee's leave date applied.
   */
  public final void setLevDateApplied(final Date argLevDateApplied) {
    this.levDateApplied = argLevDateApplied;
  }
  /**
   *
   * @param argLevStartDate to set the start date of leave.
   */
  public final void setLevStartDate(final Date argLevStartDate) {
    this.levStartDate = argLevStartDate;
  }
  /**
   *
   * @param argLevEndDate to set end date of leave.
   */
  public final void setLevEndDate(final Date argLevEndDate) {
    this.levEndDate = argLevEndDate;
  }
  /**
   *
   * @param argLevNoOfDays to set no. of days of leave.
   */
  public final void setLevNoOfDays(final int argLevNoOfDays) {
    this.levNoOfDays = argLevNoOfDays;
  }
  
  /**
   *
   * @param argLevReason to set the reason of leave..
   */
  public final void setLevReason(final String argLevReason) {
    this.levReason = argLevReason;
  }
  
  /**
   *
   * @param argLevEmpId to set employee id.
   */
  public final void setLevEmpId(final int argLevEmpId) {
    this.levEmpId = argLevEmpId;
  }
  /**
   * The dao for Leave Details.
   *@return db connection.
   */
  public static LeaveDetailsDAO dao() {
    DbConnection db = new DbConnection();
    return db.getConnect().onDemand(LeaveDetailsDAO.class);
  }
  
  /**
   * list employee Leave details by id.
   * @param empID id to get employee details.
   * @return LeaveDetails and history of leaves.
   */
  public static LeaveDetails[] listById(final int empID) {
    List<LeaveDetails> es = dao().leaveHistory(empID);
    return es.toArray(new LeaveDetails[es.size()]);
  }
  @Override
  public final String toString() {
    return   levId + " \t " + levDateApplied + " \t " + levStartDate
      + " \t " + levEndDate + " \t " + levNoOfDays + " \t " + levReason
      + "\t " + "\t" + levEmpId;
  }
  
}
