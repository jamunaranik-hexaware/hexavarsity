package com.hexaware.lms.persistence;


import com.hexaware.lms.model.LeaveDetails;


import java.util.List;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;

import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;

/**
 * The DAO class for LeaveDetails.
 */
public interface LeaveDetailsDAO  {
  
  /**
   * return all the details of all the Leave Table.
   * @param empId is used to return leave details of employee.
   * @return the LeaveDetails array
   */
  @SqlQuery("SELECT * FROM LEAVE_DETAILS WHERE EMP_ID= :empId order by LEV_DATE_APPLIED DESC")
  @Mapper(LeaveDetailsMapper.class)
  List<LeaveDetails> leaveHistory(@Bind("empId") int empId);

  /**
    * Updates the leave balance of the employee after applying leave.
    * Updating the leave balance.
    * @param balance to show the leave balance.
    * @param empId to get the employee id.
    * @return the updated leave balance of the employee.
    */
  @SqlUpdate("UPDATE EMPLOYEE SET EMP_LEV_BALANCE= :balance WHERE EMP_ID= :empId")
  int updateLeave(@Bind("balance") int balance, @Bind("empId") int empId);
  
  
 /**
   * Inserts details in leave table.
   * Applying for leave
   * @param levNoOfDays to initialize no of days of leave.
   * @param levStartDate to initialize leave start date.
   * @param levEndDate to initialize leave end date.
   * @param levStatus to initialize leave status.
   * @param levType to initialize leave type.
   * @param levReason to initialize leave reason.
   * @param levEmpId to initialize leave employee id.
   * @return the apply leave details of employee.
   */
  @SqlUpdate("INSERT INTO LEAVE_DETAILS(LEV_START_DATE,LEV_END_DATE,LEV_NO_OF_DAYS, "
      + " LEV_REASON, EMP_ID) VALUES (:levStartDate, :levEndDate, :levNoOfDays,"
      + " :levReason, :levEmpId)")
  int applyForLeave(@Bind("levStartDate") String levStartDate, @Bind("levEndDate") String levEndDate,
      @Bind("levNoOfDays") int levNoOfDays,  @Bind("levReason") String levReason, @Bind("levEmpId") int levEmpId);
 
  
  /**
  * close with no args is used to close the connection.
  */
  void close();
}
