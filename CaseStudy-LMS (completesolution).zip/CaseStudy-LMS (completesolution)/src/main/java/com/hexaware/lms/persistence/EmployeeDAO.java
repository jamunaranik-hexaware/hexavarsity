
package com.hexaware.lms.persistence;

import com.hexaware.lms.model.Employee;


import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;

import java.util.List;

/**
 * The DAO class for employee.
 */
public interface EmployeeDAO  {
  /**
   * return all the details of all the employees.
   * @return the employee array
   */
  @SqlQuery("SELECT * FROM EMPLOYEE")
  @Mapper(EmployeeMapper.class)
  List<Employee> list();
  /**
   * return all the details of the selected employee.
   * @param empID the id of the employee
   * @return the employee object
   */
  @SqlQuery("SELECT * FROM EMPLOYEE WHERE EMP_ID = :empID")
  @Mapper(EmployeeMapper.class)
  Employee find(@Bind("empID") int empID);
 

  /**
   * updates the employee table with available leaves.
   * @param empId the id of the employee
   * @param day the id of the employee
   * @return 1 on updation
   */
  @SqlUpdate("update EMPLOYEE set EMP_LEV_BALANCE =:day WHERE EMP_ID = :empID")
  int updateBalAvailable(@Bind("day") int day, @Bind("empID") int empId);

  /**
  * close with no args is used to close the connection.
  */
  void close();
}
