package com.hexaware.lms.util;
import java.util.Scanner;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.InputMismatchException;
import com.hexaware.lms.model.Employee;
import com.hexaware.lms.model.LeaveDetails;
import java.text.ParseException;

/**
 * Class CliMain provides the command line interface to the leavemanagement
 * application.
 */
public class CliMain {
  private Scanner option = new Scanner(System.in, "UTF-8");

  private void mainMenu() {
   
      System.out.println("\nLeave Management System");
      System.out.println("-----------------------");
      System.out.println("1. List All Employees Info");
      System.out.println("2. Apply for leave");
      System.out.println("3. Leave History");
      System.out.println("4. Exit");
      System.out.println("\nEnter your choice:");
      int menuOption = option.nextInt();
      
      mainMenuDetails(menuOption);
   
  }
  private void mainMenuDetails(final int selectedOption) {
    switch (selectedOption) {
      case 1:
        listEmployeesDetails();
        break;
      case 2:
        applyForLev();
        break;
      case 3:
        leaveHistory();
        break;
      case 4:
        // halt since normal exit throws a stacktrace due to jdbc threads not responding
        Runtime.getRuntime().halt(0);
      default:
        System.out.println("Choose any of the Following Option:\n");
    }
    mainMenu();
  }
  
  private void listEmployeesDetails() {
    Employee[] employee = Employee.listAll();
    for (Employee e : employee) {
      System.out.println(e.getEmpId() + " \t " + e.getEmpName() + "\t" + e.getMgrId() + "\t" + e.getEmpLevBalance());
    }
  }
  

    
  private void leaveHistory()  {
    int empId = 0;
    System.out.println("Enter an Employee Id");
    
      empId = option.nextInt();
    
      LeaveDetails[] leavedetail = LeaveDetails.listById(empId);
        if (leavedetail.length == 0) {
          System.out.println("Sorry no leave history exists for this employee.");
        } else {
          System.out.println("LeaveID" + "\t" + "LeaveDateApplied" + " " + "leaveStartDate" + " " + "LeaveEndDate"
              + " " + "Noofdays" + "\t " + " \t" + "ReasonForLeave"
                  + "\t " + "Employee Id");
          for (LeaveDetails l:leavedetail) {
            System.out.println(l);
          }
        }
      
    
  }
  private void applyForLev() {
    int levEmpId = 0;
    int levNoOfDays = 0;
    System.out.println("Enter the employee id");
    try {
      levEmpId = option.nextInt();
      Employee emp = Employee.listById(levEmpId);
      if (emp == null) {
        System.out.println("No Such Employee Found");
      } else {
        System.out.println("Available Leave balance:" + emp.getEmpLevBalance());
        if (emp.getEmpLevBalance() == 0) {
          System.out.println("Insufficient Leave Balance. You cannot apply for leave");
        } else {
          System.out.println("Enter total leave days");
          levNoOfDays = option.nextInt();
          if (levNoOfDays <= 0) {
            System.out.println("please enter valid number of days");
            option.nextLine();
          } else {
            System.out.println("Enter the start date(YYYY-MM-DD)");
            Date date1 = null;
            SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
            sdf1.setLenient(false);
            String startDate = option.next();
            date1 = sdf1.parse(startDate);
            if (date1 == null) {
              System.out.println("Please Enter Date In This format(YYYY-MM-DD)");
              option.nextLine();
            }
            System.out.println("Enter the end date(YYYY-MM-DD)");
            Date date2 = null;
            SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
            sdf2.setLenient(false);
            String endDate = option.next();
            date2 = sdf2.parse(endDate);
            if (date2 == null) {
              System.out.println("Please Enter the date in correct format (YYYY-MM-DD)");
              option.nextLine();
            } else {
              option.nextLine();
              System.out.println("Enter the reason");
              String reason = option.next();
              String l = Employee.applyLev(sdf1.format(date1), sdf1.format(date2), levNoOfDays,
                  reason, levEmpId);
              System.out.println(l);
            }
          }
        }
      }
    } catch (InputMismatchException a) {
      System.out.println("Enter Correct input");
      option.nextLine();
    } catch (ParseException c) {
      System.out.println("Please Enter date in correct format");
      option.nextLine();
    }
  }
   /**
   * The main entry point.
   * @param ar the list of arguments
   */
  public static void main(final String[] ar) {
    final CliMain mainObj = new CliMain();
    mainObj.mainMenu();
  }
}
