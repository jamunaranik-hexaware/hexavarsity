package com.hexa.lms;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class CliMain {

	Scanner option = new Scanner(System.in);

	private void mainMenu() {

		System.out.println("\nLeave Management System");
		System.out.println("-----------------------");
		System.out.println("1. Listing Employee Info");
		System.out.println("2. Apply for leave");
		System.out.println("3. Leave History");
		System.out.println("4. Exit");
		System.out.println("\nEnter your choice:");
		int menuOption = option.nextInt();

		mainMenuDetails(menuOption);

	}

	private void mainMenuDetails(final int selectedOption) {
		switch (selectedOption) {
		case 1:
			listEmployeeDetail();
			break;
		case 2:
			applyForLev();
			break;
		case 3:
			leaveHistory();
			break;
		case 4:
			// halt since normal exit throws a stacktrace due to jdbc threads not responding
			Runtime.getRuntime().halt(0);
		default:
			System.out.println("Choose any of the Following Option:\n");
		}
		mainMenu();
	}

	private void listEmployeeDetail() {
		
	}

	private void leaveHistory() {
		
	}

	private void applyForLev() {

		
	}

	public static void main(String[] args) {
		final CliMain mainObj = new CliMain();
		mainObj.mainMenu();
	}
}