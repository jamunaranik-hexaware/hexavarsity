package com.hexa.lms;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection {
	public static Connection getConnect() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");

		} catch (ClassNotFoundException clse) {
			clse.printStackTrace();
		}
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/lms?useSSL=false", "root", "Password123");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}

}
