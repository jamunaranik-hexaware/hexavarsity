package com.hexa.lms;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class CliMain {

	Scanner option = new Scanner(System.in);

	private void mainMenu() {

		System.out.println("\nLeave Management System");
		System.out.println("-----------------------");
		System.out.println("1. Listing Employee Info");
		System.out.println("2. Apply for leave");
		System.out.println("3. Leave History");
		System.out.println("4. Exit");
		System.out.println("\nEnter your choice:");
		int menuOption = option.nextInt();

		mainMenuDetails(menuOption);

	}

	private void mainMenuDetails(final int selectedOption) {
		switch (selectedOption) {
		case 1:
			listEmployeeDetail();
			break;
		case 2:
			applyForLev();
			break;
		case 3:
			leaveHistory();
			break;
		case 4:
			// halt since normal exit throws a stacktrace due to jdbc threads not responding
			Runtime.getRuntime().halt(0);
		default:
			System.out.println("Choose any of the Following Option:\n");
		}
		mainMenu();
	}

	private void listEmployeeDetail() {
		System.out.println("Enter Employee Id");
		int eid = option.nextInt();
		Employee employee = Employee.listById(eid);
		System.out.println("EmpID" + "\t" + "EmpName" + " " + "MgrId" + "\t " + "LeaveBalance" + "\t" + "DepName");
		System.out.println(employee.getEmpId() + "\t" + employee.getEmpName() + "\t" + employee.getEmpMgrId() + "\t   "
					+ employee.getEmpLevBalance() + " \t       " + employee.getEmpDepName());
		
	}

	private void leaveHistory() {
		System.out.println("Enter Employee Id");
		int eid = option.nextInt();
		List<LeaveDetails> ld = LeaveDetails.listById(eid);
		Iterator<LeaveDetails> it = ld.iterator();
		System.out.println("LeaveID" + "\t" + "DateApplied" + " " + "LeaStartDate" + " " + "LeaEndDate" + " "
				+ "Noofdays" + "\t " + "LeaveReason" + "\t "+"\t" + "EmpId");
		while (it.hasNext()) {
			LeaveDetails l = it.next();
			System.out.println(
					l.getLevId() + "\t" + l.getLevDateApplied() + "  " + l.getLevStartDate() + " " + l.getLevEndDate()
							+ " \t " + l.getLevNoOfDays() + "\t" + "\t" + l.getLevReason() + " \t "+"\t" + l.getLevEmpId());
		}

	}

	private void applyForLev() {

		int levNoOfDays = 0;
		System.out.println("Enter the employee id");
		try {
			int empId = option.nextInt();
			System.out.println("Enter total leave days");
			levNoOfDays = option.nextInt();
			System.out.println("Enter the start date(YYYY-MM-DD)");
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
			sdf1.setLenient(false);
			String startDate = option.next();
			Date date1 = sdf1.parse(startDate);
			System.out.println("Enter the end date(YYYY-MM-DD)");
			String endDate = option.next();
			Date date2 = sdf1.parse(endDate);
			System.out.println("Enter the reason");
			String reason = option.next();
			String l = Employee.applyLev(sdf1.format(date1), sdf1.format(date2), levNoOfDays, reason, empId);
			System.out.println(l);
		} catch (ParseException ex) {
			System.out.println(ex);
		}
	}

	public static void main(String[] args) {
		final CliMain mainObj = new CliMain();
		mainObj.mainMenu();
	}
}