package com.hexa.lms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

public class Employee {

	private int empId;
	private String empName;
	private int empMgrId;
	private int empLevBalance;
	private String empDepName;
	private static Connection con = null;

	public int getEmpMgrId() {
		return empMgrId;
	}

	public void setEmpMgrId(int empMgrId) {
		this.empMgrId = empMgrId;
	}

	public String getEmpDepName() {
		return empDepName;
	}

	public void setEmpDepName(String empDepName) {
		this.empDepName = empDepName;
	}

	@Override
	public final boolean equals(final Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Employee emp = (Employee) obj;
		if (Objects.equals(empId, emp.empId) && Objects.equals(empName, emp.empName)
				&& Objects.equals(empMgrId, emp.empMgrId) && Objects.equals(empLevBalance, emp.empLevBalance)
				&& Objects.equals(empDepName, emp.empDepName)) {
			return true;
		}
		return false;
	}

	@Override
	public final int hashCode() {
		return Objects.hash(empId, empName, empMgrId, empLevBalance, empDepName);
	}

	public Employee(final int argEmpId, final String argEmpName, final int argEmpMgrId, final int argEmpLevBalance,
			final String argDepName) {
		this.empId = argEmpId;
		this.empName = argEmpName;
		this.empMgrId = argEmpMgrId;
		this.empLevBalance = argEmpLevBalance;
		this.empDepName = argDepName;
	}

	public Employee() {
	}

	public final int getEmpId() {
		return empId;
	}

	public final String getEmpName() {
		return empName;
	}

	public final int getEmpLevBalance() {
		return empLevBalance;
	}

	public final void setEmpId(final int argEmpId) {
		this.empId = argEmpId;
	}

	public final void setEmpName(final String argEmpName) {
		this.empName = argEmpName;
	}

	public final void setEmpLevBalance(final int argEmpLevBalance) {
		this.empLevBalance = argEmpLevBalance;
	}

	public static Employee listById(final int empID) {
		
		Employee emp = null;
		con = DbConnection.getConnect();
		try {
			PreparedStatement st = con.prepareStatement("SELECT * FROM EMPLOYEE WHERE EMP_ID=?");
			st.setInt(1, empID);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				emp = new Employee(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5));
			}
		} catch (SQLException ex) {
			System.out.println(ex);
		}
		return emp;
	}

	public static String applyLev(final String levStartDate, String levEndDate, final int levNoOfDays,
			final String levReason, final int levEmpId) {
		con = DbConnection.getConnect();
		int leaveBalance = 0;
		String msg = null;
		try {
			Employee emp = Employee.listById(levEmpId);
			leaveBalance = emp.getEmpLevBalance();
			
			if (levNoOfDays > leaveBalance) {
				msg = "Insufficient Balance !!";
			} else {

				PreparedStatement st = con.prepareStatement(
						"INSERT INTO LEAVE_DETAILS(LEV_START_DATE,LEV_END_DATE,LEV_NO_OF_DAYS,LEV_REASON, EMP_ID) VALUES (?,?,?,?,?)");
				st.setString(1, levStartDate);
				st.setString(2, levEndDate);
				st.setInt(3, levNoOfDays);
				st.setString(4, levReason);
				st.setInt(5, levEmpId);
				st.executeUpdate();
				int levBalance = leaveBalance - levNoOfDays;
				PreparedStatement ps = con.prepareStatement("UPDATE EMPLOYEE SET EMP_LEV_BALANCE= ? WHERE EMP_ID= ?");
				ps.setInt(1, levBalance);
				ps.setInt(2, levEmpId);
				ps.executeUpdate();
				msg = "Your Leave Approval sent to manager";
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		return msg;
	}

}
